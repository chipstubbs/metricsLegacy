#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `spouse` varchar(50) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `userpic` varchar(150) NOT NULL DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `has_assets` int(11) DEFAULT '0',
  `hot_client` int(11) DEFAULT '0',
  `hot_prospect` int(11) DEFAULT '0',
  `referral` int(11) DEFAULT '0',
  `sched_appt_check` int(11) DEFAULT '0',
  `sched_appt` int(11) DEFAULT '0',
  `appt_date` varchar(20) DEFAULT NULL,
  `kept_appt` int(11) DEFAULT '0',
  `acat` int(11) DEFAULT '0',
  `acat_xfered` int(140) DEFAULT '0',
  `annuity_app` int(11) DEFAULT '0',
  `annuity_prem_app` int(140) DEFAULT '0',
  `annuity_paid` int(11) DEFAULT '0',
  `annuity_paid_prem` int(140) DEFAULT '0',
  `annuity_paid_comm` int(140) DEFAULT '0',
  `other` int(11) DEFAULT '0',
  `other_deposit` int(140) DEFAULT '0',
  `life_amount` int(140) DEFAULT NULL,
  `other_comm` int(140) DEFAULT '0',
  `life_submitted` int(11) DEFAULT '0',
  `life_date` varchar(20) DEFAULT NULL,
  `life_commission` decimal(3,0) DEFAULT '0',
  `aum` int(11) DEFAULT NULL,
  `aum_amount` int(140) DEFAULT '0',
  `last_contact` varchar(50) DEFAULT NULL,
  `follow_up` varchar(50) DEFAULT NULL,
  `prospect_opportunity` int(140) DEFAULT '0',
  `closing_probability` int(11) DEFAULT '0',
  `p_probable_acat_size` int(140) DEFAULT '0',
  `prospect_comment` longtext NOT NULL,
  `c_last_contact` varchar(45) DEFAULT NULL,
  `c_follow_up` varchar(45) DEFAULT NULL,
  `client_opportunity` int(140) DEFAULT '0',
  `c_closing_probability` int(11) DEFAULT '0',
  `c_probable_acat_size` int(140) DEFAULT '0',
  `client_comment` longtext NOT NULL,
  `prospect` int(11) DEFAULT '0',
  `client` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('27', '25', 'Clark', 'Kent', NULL, 'cstubbs@advisorsacademy.com', '1234567890', '', '', '', '19', '1f0f66149b097adbd0a9abd8990e317a.jpg', 'Westbrook', 'password', '0', '14,12', '0', '1428954785', '0', '0', '0', '0', '1', '1', '05/01/2015', '0', '1', '50000000', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('28', '26', 'Nick', 'Borgert', NULL, 'nborgert@advisorsacademy.com', '', '', '', '', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '12', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('29', '25', 'Client 1', 'Tester', NULL, 'cstubbs@advisorsacademycom', '1234567890', '33333333333333', '6550 N Federal Hwy Suite 500', '33308', '19', '66dfc72b0f94f11ed36fa49cb627494e.jpg', 'Fort Lauderdale', 'password', '0', '12', NULL, NULL, '1', '1', '1', NULL, '1', '1', '04/21/2015', '1', '1', '20000000', '1', '100001', '1', '100000', '3', '1', '50000000', '0', '3', NULL, '04/29/2015', '4', NULL, '0', '2015-05-08 23:12:12', '05/14/2015', '100000000', '25', '200000000', 'Changing it up a bit PROSPECT', '05/15/2015', '05/15/2015', '300000001', '75', '400000000', 'Client comment section no html', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('31', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('32', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('33', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('34', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('35', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', '22', 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '1', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('36', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('37', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('38', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('39', '25', 'Test', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('40', '25', 'Lindsay', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', '15', 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('41', '25', 'Chipper', 'Test', NULL, 'chip06@gmail.com', '1234567903', '1234567890', '6550 N Federal Hwy, Suite 500', '33308', '19', 'no-pic.png', 'Fort Lauderdale', 'password', '0', '14,12,10', NULL, NULL, '1', '0', '1', '0', '1', '2', '04/17/2015', '1', '0', '0', '0', '0', '1', '30000055', '4', '1', '100000000', '0', '7', '0', '', '0', '0', '0', '2015-05-12 23:12:12', NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('42', '25', 'John', 'Smith', NULL, 'johnsmith@example.com', '9999999999', '', '123 Appleseed Road, Apt 14', '12345', '19', '01b213dc955bd004076139e07e7d801a.jpg', 'Miami', 'password', '0', '0', NULL, NULL, '0', '1', '1', '0', '1', '1', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('43', '25', 'Add', 'Test', NULL, 'Johnsmith@lol.com', '9999999999', '', '1234 Seahouse Street', '12345', NULL, 'no-pic.png', 'Miami', 'password', '0', '0', NULL, NULL, '1', '0', '1', '0', '1', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('44', '25', 'Add2', 'Test2', NULL, '2Johnsmith@lol.com', '8888888888', '', '6550 N Federal Hwy, Suite 500', '33308', NULL, 'no-pic.png', 'Fort Lauderdale', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '1', '1', '04/15/2015', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('45', '25', 'Add2', 'Tester', NULL, 'chips@knights.ucf.edu', '1232222222', '', '', '', NULL, 'no-pic.png', 'asdf', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '1', '3', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('46', '25', 'Add2', 'Test2', NULL, 'chip06@gmail.com', '9999999999', '', '', '', NULL, 'no-pic.png', 'Sebastian', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('47', '25', '33333', '33333', NULL, 'chips@knights.ucf.edu', '3333333333', '', '', '', NULL, 'no-pic.png', 'asdf', 'password', '0', '0', NULL, NULL, '0', '1', '0', '0', '0', '3', NULL, '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('48', '25', 'Add2', 'Tester', '', 'chips@knightsucfedu', '8888888888', '', '', '', '0', 'no-pic.png', 'asdf', 'password', '0', '0', NULL, NULL, '0', '0', '1', '0', '1', '2', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '05/18/2015', '05/22/2015', '100000000', '50', '45000000', 'Coming back in friday to follow up and probably close', '', '', '0', '25', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('49', '25', 'Add', 'asdfasdfasdf', NULL, 'chips@knights.ucf.edu', '3333333333', '', '3', '', NULL, 'no-pic.png', 'Sebastian', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('50', '26', 'Koala', 'Kid', NULL, 'koala@kid.com', '3453453453', '', '', '', NULL, 'no-pic.png', 'Zimbabwe', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `spouse`, `email`, `phone`, `mobile`, `address`, `zipcode`, `event_id`, `userpic`, `city`, `password`, `inactive`, `access`, `last_active`, `last_login`, `has_assets`, `hot_client`, `hot_prospect`, `referral`, `sched_appt_check`, `sched_appt`, `appt_date`, `kept_appt`, `acat`, `acat_xfered`, `annuity_app`, `annuity_prem_app`, `annuity_paid`, `annuity_paid_prem`, `annuity_paid_comm`, `other`, `other_deposit`, `life_amount`, `other_comm`, `life_submitted`, `life_date`, `life_commission`, `aum`, `aum_amount`, `last_contact`, `follow_up`, `prospect_opportunity`, `closing_probability`, `p_probable_acat_size`, `prospect_comment`, `c_last_contact`, `c_follow_up`, `client_opportunity`, `c_closing_probability`, `c_probable_acat_size`, `client_comment`, `prospect`, `client`) VALUES ('51', '25', 'Kangaroo', 'Kid', NULL, 'kangaroo@kid.com', '7776665577', '', '', '', NULL, 'no-pic.png', 'Kang\'Aroo', 'password', '0', '0', NULL, NULL, '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', NULL, '0', NULL, NULL, '0', '0', '0', '', NULL, NULL, '0', '0', '0', '', '0', '0');


#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `user_id` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO companies (`id`, `reference`, `name`, `user_id`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('25', '41001', 'Scranton Financial Group', NULL, '27', '123-456-7890', '', '6550 N Federal Hwy, Suite 500', '33301', 'Fort Lauderdale', '0', 'metrics.advisorsacademy.com', 'USA', 'What? lol', NULL, 'Florida');
INSERT INTO companies (`id`, `reference`, `name`, `user_id`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('26', '41002', 'Advisors Academy', NULL, '28', '', '', '', '', 'Fort Lauderdale', '0', '', 'USA', '', NULL, 'Florida');
INSERT INTO companies (`id`, `reference`, `name`, `user_id`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('27', '41003', 'Structus', NULL, NULL, '', '', '', '', '', '0', '', '', '', NULL, '');


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT '',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT '0',
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT '0',
  `ticket_config_active` int(11) DEFAULT '0',
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT '',
  `stripe_currency` varchar(255) DEFAULT 'USD',
  `bank_transfer` int(11) DEFAULT '0',
  `bank_transfer_text` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `stripe_currency`, `bank_transfer`, `bank_transfer_text`) VALUES ('1', '2.2.8', 'http://localhost/metrics/', 'cstubbs@advisorsacademy.com', 'Advisors\' Academy', '0', '$', '1', '1', '0', '0', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '41004', '6', '31001', '61001', '10000', 'm/d/Y', 'g:i A', 'New Invoice', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'english', '6550 N Federal Highway', 'Fort Lauderdale', 'David Scranton', '877-399-1933', 'New Subscription', 'files/media/AAWordmark_27x2001.png', 'blueline', '0', 'USD', '', 'files/media/AAWordmark_27x2002.png', 'bc62f7cb-5646-47c2-96a5-922076f37575', NULL, NULL, '1', '1', '1', 'new', NULL, NULL, NULL, NULL, NULL, NULL, '/notls', 'UNSEEN', '0', NULL, '0', '0', '1', '0', NULL, '', 'USD', '0', '');


#
# TABLE STRUCTURE FOR: custom_quotation_requests
#

DROP TABLE IF EXISTS custom_quotation_requests;

CREATE TABLE `custom_quotation_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form` longtext NOT NULL,
  `custom_quotation_id` int(11) unsigned NOT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_quotations
#

DROP TABLE IF EXISTS custom_quotations;

CREATE TABLE `custom_quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '',
  `formcontent` longtext NOT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice_has_items
#

DROP TABLE IF EXISTS invoice_has_items;

CREATE TABLE `invoice_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS invoices;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT NULL,
  `sent_date` varchar(20) DEFAULT NULL,
  `paid_date` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscription_id` varchar(50) DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` float DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`) VALUES ('1', 'Test Item', '0', 'Test type for Item', '0');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO messages (`id`, `project_id`, `media_id`, `from`, `text`, `datetime`) VALUES ('26', '12', '30', 'David Scranton', '<p>Test comment on Image uploaded! (Long exposure of road in Norway)</p>', '2015-03-20 15:38');


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'icon-th', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'icon-inbox', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects2', 'projects', 'main', 'icon-briefcase', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'icon-user', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'icon-list-alt', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'icon-file', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'icon-list-alt', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'icon-calendar', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'icon-cog', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', NULL, '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', NULL, '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Projects', 'cprojects', 'client', 'icon-briefcase', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Invoices', 'cinvoices', 'client-old', 'icon-list-alt', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('14', 'Messages', 'cmessages', 'client', 'icon-inbox', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('15', 'Subscriptions', 'csubscriptions', 'client-old', 'icon-calendar', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('16', 'Tickets', 'tickets', 'main', 'icon-tag', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('17', 'Tickets', 'ctickets', 'client-old', 'icon-tag', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('18', 'Users', 'settings/users', 'main', 'icon-user', '9');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) NOT NULL,
  `sender` varchar(250) NOT NULL,
  `recipient` varchar(250) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) NOT NULL,
  `conversation` varchar(32) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT '',
  `attachment_link` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('38', 'Read', 'u10', 'u9', 'Subject', '<p>Message</p>', '2015-04-13 22:54', 'c1ce77ee39aaa287ecc1fe58550fb080', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('39', 'Read', 'u10', 'u9', 'asdfasfasd', '<p>fasdfasdfasdf</p>', '2015-04-16 21:39', '2e1395c3b13bcf49394b58ae912ef6c6', '0', '', '');


#
# TABLE STRUCTURE FOR: production
#

DROP TABLE IF EXISTS production;

CREATE TABLE `production` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `c_fname` varchar(45) DEFAULT NULL,
  `c_lname` varchar(45) DEFAULT NULL,
  `fmo` varchar(45) DEFAULT NULL,
  `product_co` varchar(45) DEFAULT NULL,
  `product_name` varchar(45) DEFAULT NULL,
  `production_submitted` varchar(20) DEFAULT NULL,
  `production_processed` varchar(20) DEFAULT NULL,
  `production_amount` decimal(65,2) DEFAULT '0.00',
  `prem_paid_month` varchar(20) DEFAULT NULL,
  `prem_paid` decimal(65,2) DEFAULT '0.00',
  `comp_agent_name` varchar(45) DEFAULT NULL,
  `comp_agent_percent` decimal(3,0) DEFAULT NULL,
  `comm_paid` decimal(65,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('1', '14', 'What', 'The ', 'Fuck', NULL, NULL, '2015-04-17', NULL, '0.00', NULL, '0.00', NULL, NULL, '0.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('4', '14', 'Bruce', 'Wayne', 'Advisors Academy', 'SFG', 'Inc Sel 10', '2015-04-17', '2015-04-16', '48880.00', '2015-04-16', '2000.00', 'AgentNine', '8', '35000.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('6', '14', '3333', '3333', 'FMO', 'Company', 'Product', '2015-04-17', '2015-04-17', '1.00', '2015-04-16', '0.00', 'Agent of the Nine', '50', '1000033.44');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('7', '14', 'Name', 'Name', 'asasdf', 'asdf', 'asdf', '2015-04-16', '2015-04-16', '1000.00', NULL, '0.00', NULL, NULL, '0.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('8', '14', 'asda', 'Test Last', 'DFMO', 'asdf', 'asdf', '2015-04-17', '2015-04-08', '111111.00', '', '0.00', '', '0', '1.50');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('9', '14', 'Chip', 'Stubbs', 'FMO', 'Company', 'Product 10', '2014-04-16', '04-17-2015', '1000.00', '04-20-2015', '500.00', 'Double O 7', '5', '3000.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('10', '14', 'aaaaa', 'aaa', 'aaaaa', 'aaaa', 'aaaaa', '2015-04-01', '2015-04-03', '111111.00', '2015-04-09', '1111111.00', 'Double O 7', '2', '2222222.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('11', '14', 'bbbbb', 'bbbbb', 'bbbbb', 'bbbbbb', 'bbbbbb', '2015-04-16', '2015-04-11', '333333.00', '2015-04-10', '333333333.00', 'Double O 7', '5', '33333333.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('13', '14', 'aaaaa', 'aaa', 'aaaaa', 'aaaa', 'aaaaa', '2015-04-01', '2015-04-03', '111111.00', '2015-04-09', '1111111.00', 'Double O 7', '2', '2222222.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('14', '14', 'Bill', 'Smith', 'OMF', 'Company', 'Product 20', '2015-04-16', '2015-04-17', '100.00', '2015-04-17', '50.10', 'Smithers', '41', '25.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('15', '14', 'Test', 'Smith', 'MOF', 'Comp', 'Inc Sel 10', '', '2015-04-16', '1200.00', '2015-04-17', '100.12', 'AgentNine', '50', '100.00');
INSERT INTO production (`id`, `pid`, `c_fname`, `c_lname`, `fmo`, `product_co`, `product_name`, `production_submitted`, `production_processed`, `production_amount`, `prem_paid_month`, `prem_paid`, `comp_agent_name`, `comp_agent_percent`, `comm_paid`) VALUES ('17', '14', 'asdfasdf', 'asdfasdfa', 'w323', 'asdfasdf', 'asadfa', '2015-04-16', '2015-04-18', '333333.00', '2015-04-16', '345345345.66', 'asefwer', '4', '11000.00');


#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` longtext,
  `type` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('2', '12', '9', '0', '1426862275', 'Media file has been added', '<b>David Scranton</b> uploaded Test Image Upload', 'media');


#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT '0',
  `name` varchar(120) DEFAULT '0',
  `filename` varchar(150) DEFAULT '0',
  `description` text,
  `savename` varchar(200) DEFAULT '0',
  `phase` varchar(100) DEFAULT '0',
  `date` varchar(50) DEFAULT '0',
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('30', '12', '9', '0', 'image/jpeg', 'Test Image Upload', '10minShutter_Norway.jpg', 'Uploading an image to see where it is in DB', '69eb7d092f25f70e80c8268908810e36.jpg', ' Developing', '2015-03-20 15:37', '0');


#
# TABLE STRUCTURE FOR: project_has_invoices
#

DROP TABLE IF EXISTS project_has_invoices;

CREATE TABLE `project_has_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `invoice_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `name` varchar(250) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT '0',
  `public` int(10) DEFAULT '0',
  `datetime` int(11) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `description` text,
  `value` int(11) DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT '0',
  `custom1` int(11) DEFAULT NULL,
  `custom2` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `custom1`, `custom2`) VALUES ('1', '12', 'Test Task', '10', 'done', '0', NULL, '2015-03-26', '<p>Description of Test Task</p>', '0', '2', '0', '3', NULL);


#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('41', '11', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('42', '12', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('44', '13', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('46', '14', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('47', '15', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('48', '16', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('49', '17', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('50', '18', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('51', '19', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('52', '20', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('53', '21', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('54', '22', '10');


#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `name` varchar(65) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `event` varchar(45) DEFAULT NULL,
  `location` varchar(65) DEFAULT NULL,
  `zip_codes` varchar(45) DEFAULT NULL,
  `filters` varchar(45) DEFAULT NULL,
  `event_date` varchar(20) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `sticky` enum('1','0') DEFAULT '0',
  `category` varchar(150) DEFAULT NULL,
  `note` longtext NOT NULL,
  `progress_calc` tinyint(4) DEFAULT '0',
  `number_mailers` int(140) DEFAULT '0',
  `total_responses` int(140) DEFAULT '0',
  `attended` int(140) DEFAULT '0',
  `bu_attended` int(140) DEFAULT '0',
  `total_appt_sched` int(140) DEFAULT '0',
  `first_appt_pending` int(140) DEFAULT '0',
  `appt_kept` int(140) DEFAULT '0',
  `appt_closed` int(140) DEFAULT '0',
  `acat_business_metric` int(140) DEFAULT '0',
  `total_annuity_prem` int(140) DEFAULT '0',
  `percent_to_annuity` int(140) DEFAULT '0',
  `total_annuity_comm` int(140) DEFAULT '0',
  `total_prem_value` int(140) DEFAULT '0',
  `total_other_comm` int(140) DEFAULT '0',
  `total_event_cost` int(140) DEFAULT '0',
  `people_with_assets` int(140) DEFAULT '0',
  `percent_with_assets` int(140) DEFAULT '0',
  `num_buying_completed` int(140) DEFAULT '0',
  `name_or_venue` varchar(45) DEFAULT NULL,
  `ad` int(140) DEFAULT '0',
  `ad_cost` int(140) DEFAULT '0',
  `other_invite` int(140) DEFAULT '0',
  `other_invite_cost` int(140) DEFAULT '0',
  `mailers_cost` int(140) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_projects_clients1` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('12', '6', '1', '25', 'platinumreferral', 'Fort Meyers', '12345, 67890', '', '03/19/2015', 'So and so did a Federal employee benefits special seminar to explain the benefits of blah blah blah.', '2015-03-19', '2015-03-26', '0', 'Planning, Developing, Testing', '0', '0', '1426785973', '0', 'Shoe Category', '&lt;p&gt;Notes to save if needed for each metric.&lt;/p&gt;&lt;p&gt;sdrgsrhsrdgsrgsdrrgs&lt;/p&gt;', '0', '25', '15', '10', '5', '5', '5', '3', '3', '500000', '1000000', '50', '1000000', '500000', '500000', '5000', '3', '0', '3', '', '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('14', '123', '1', '25', 'rmd', 'Sebastian', '', '', '03/20/2015', '', NULL, NULL, '0', NULL, NULL, NULL, '1428695552', '0', NULL, '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('15', '124', '6', '25', 'ss', 'Morocco', '', '', '04/29/2015', '', NULL, NULL, '0', NULL, NULL, NULL, '1430316400', '0', NULL, '', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('18', '1', '6', '26', 'ss', 'Company26', '', '', '01/26/2015', '', NULL, NULL, '0', NULL, NULL, NULL, '1430402648', '0', NULL, '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('19', '3', '6', '25', 'taxpro', 'Key West', '', '', '04/23/2015', '', NULL, NULL, '0', NULL, NULL, NULL, '1430403791', '1', NULL, '', '0', '0', '0', '10', '10', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '12000', '0', '0', '0', NULL, '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('20', '16', '4', '25', '', '', '', '', '05/13/2015', '', NULL, NULL, '0', NULL, '0', '4', '1431443689', '0', NULL, '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('21', '4', '6', '25', NULL, '', '', '', '', '', NULL, NULL, '0', NULL, NULL, NULL, '1431444083', '0', NULL, '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `company_id`, `event`, `location`, `zip_codes`, `filters`, `event_date`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `note`, `progress_calc`, `number_mailers`, `total_responses`, `attended`, `bu_attended`, `total_appt_sched`, `first_appt_pending`, `appt_kept`, `appt_closed`, `acat_business_metric`, `total_annuity_prem`, `percent_to_annuity`, `total_annuity_comm`, `total_prem_value`, `total_other_comm`, `total_event_cost`, `people_with_assets`, `percent_with_assets`, `num_buying_completed`, `name_or_venue`, `ad`, `ad_cost`, `other_invite`, `other_invite_cost`, `mailers_cost`) VALUES ('22', '6', '6', '25', 'college', 'awrgasrgasrdgazsrgAWegWAeg', '', '', '05/20/2015', '', NULL, NULL, '0', NULL, NULL, NULL, '1431460839', '0', NULL, '', '0', '50', '50', '40', '30', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Bill Cosby', '25', '10000', '25', '7500', '25000');


#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT '0',
  `timestamp` varchar(250) DEFAULT '0',
  `token` varchar(250) DEFAULT '0',
  `user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Service', 'First service queue', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Second Level', 'Second Level Queue', '0');


#
# TABLE STRUCTURE FOR: quotations
#

DROP TABLE IF EXISTS quotations;

CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(150) DEFAULT NULL,
  `q5` text,
  `q6` varchar(50) DEFAULT NULL,
  `company` varchar(150) DEFAULT '-',
  `fullname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `comment` text,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(150) DEFAULT '0',
  `user_id` int(50) DEFAULT '0',
  `replied` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subscription_has_items
#

DROP TABLE IF EXISTS subscription_has_items;

CREATE TABLE `subscription_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: subscriptions
#

DROP TABLE IF EXISTS subscriptions;

CREATE TABLE `subscriptions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) DEFAULT NULL,
  `company_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `next_payment` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscribed` varchar(50) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `text` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `from` varchar(250) NOT NULL DEFAULT '0',
  `reply_to` varchar(250) DEFAULT '0',
  `to` varchar(250) DEFAULT '0',
  `cc` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT '0',
  `reference` varchar(250) DEFAULT '0',
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `text` text,
  `status` varchar(50) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Service Request', 'Service Requests', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) NOT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `company_id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('9', '26', 'Admin', 'David', 'Scranton', '04aae492ada17f7be3304d4a1ed0e57a72ee63b0169bc382176fa0bf9ef2c872525cfd8f087b9a1322966eb3406a204e9e4d84a253707b6c325398e22dc1cbf6', 'cstubbs@advisorsacademy.com', 'active', '1', '2013-01-01 00:00:00', '1871d8584b19994933caf54257a7b699.jpg', 'Administrator', '1,2,3,4,5,8,6,7,9,10,11,16,18', '1432046660', '1432046340', '0');
INSERT INTO users (`id`, `company_id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('10', '25', 'advisor', 'Clark', 'Kent', 'ed48f91b478a1f50924b20916858fe5d1f1eaa23a6b0928637b2acbb1d71310ba1387fa33ba184b130f80a4d67571c8c9688e8ff3856fe513d876686b179bba0', 'cstubbs@advisorsacademy.com', 'active', '0', '2015-03-17 13:00:20', 'f8d53e84a6ed61baa2d753cd152b6cfa.png', 'Daffy Duck', '1,2,3,4,10,11', '1432046302', '1432040276', '0');
INSERT INTO users (`id`, `company_id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('11', '26', 'Erika', 'Erika', 'Wilson', 'd7cc0133b7854f76b4783317c721cb6eeae219f20987bd5bff9cea25b6ec6f790201ae95126e10f40ffaaad4d306a5af15dd4d017c41a1e84d0d10287da53f35', 'ewilson@advisorsacademy.com', 'deleted', '1', '2015-04-13 11:06:08', 'no-pic.png', 'Metrics Admin', '2,3,4,18,9,10,11', NULL, NULL, '0');
INSERT INTO users (`id`, `company_id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('12', '26', 'user1', 'Test', 'Testie', 'f46bfa790696d4217387c1129788fa586c1ad4cb971bcc9ac6fa968026ffd6b0bdf0e97e41ee1c0d8e95c6478a4ef7c5af3c0a700b31f07cfb96a8ed33b4e59e', 'cstubbs@advisorsacademy.com', 'active', '0', '2015-04-20 13:14:46', 'no-pic.png', 'O_O', '1,3,4,10,11', '0', '1429550125', '0');


